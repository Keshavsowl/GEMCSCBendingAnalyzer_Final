from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = '2025mc_v3'
config.General.workArea = 'crabLogs'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.numCores = 1
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'run_GE21ana.py'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.outputDatasetTag = '2025mc_v3'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/kkeshav/tamu_mual/2025/mcfinal'
config.Data.userInputFiles = ['root://eosuser.cern.ch//eos/user/k/kkeshav/SingleMuPt30to50_neg_end_step3/Phase2_RECO_neg_end3/260109_084949/0000/step3_RECO_1.root']
config.section_('Site')
config.Site.whitelist = ['T2_CH_CERN']
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
