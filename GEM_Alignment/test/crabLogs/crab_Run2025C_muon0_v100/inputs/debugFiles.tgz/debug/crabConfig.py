from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crabLogs'
config.General.transferOutputs = True
config.General.requestName = 'Run2025C_muon0_v100'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.numCores = 1
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 2
config.Data.publication = False
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.outputDatasetTag = 'Run2025C_muon0_before_alignment'
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
