from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crabLogs'
config.General.requestName = 'Run2025D_muon0_v3'
config.section_('JobType')
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_GE21ana.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.outputDatasetTag = 'Before_alginment'
config.Data.unitsPerJob = 1
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon0/Run2025D-ZMu-PromptReco-v1/RAW-RECO'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
