from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crabLogs'
config.General.requestName = '2025mc_v1'
config.section_('JobType')
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.userInputFiles = ['root://eosuser.cern.ch//eos/user/k/kkeshav/SingleMuPt30to50/Phase2_RECO_v1/251222_014014/0000/step3_RECO_1.root']
config.Data.outLFNDirBase = '/store/user/kkeshav/tamu_mual/2025/mc'
config.Data.publication = False
config.Data.outputDatasetTag = '2025mc_v1'
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.Site.whitelist = ['T2_CH_CERN']
config.section_('User')
config.section_('Debug')
