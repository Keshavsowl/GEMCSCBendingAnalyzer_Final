from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crabLogs'
config.General.requestName = 'Run2025C_muon0_v01'
config.section_('JobType')
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.pluginName = 'Analysis'
config.JobType.inputFiles = ['./Run2025C_muon0_ZMu_150X_dataRun3_Prompt_v1_backprop_v2.db']
config.JobType.maxMemoryMB = 8000
config.JobType.numCores = 4
config.section_('Data')
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.publication = False
config.Data.unitsPerJob = 2
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'Run2025C_muon0_iteration1_after_alignment_v1'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
