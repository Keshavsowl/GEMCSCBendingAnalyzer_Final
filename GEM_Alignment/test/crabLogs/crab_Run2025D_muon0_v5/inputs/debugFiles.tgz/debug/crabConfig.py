from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Run2025D_muon0_v5'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'crabLogs'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.numCores = 1
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'Run2025C_muon0_before_alignment'
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
