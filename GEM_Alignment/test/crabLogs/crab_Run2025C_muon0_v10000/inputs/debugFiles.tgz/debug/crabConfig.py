from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'crabLogs'
config.General.requestName = 'Run2025C_muon0_v10000'
config.section_('JobType')
config.JobType.psetName = 'run_GE21ana_v1.py'
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 4
config.section_('Data')
config.Data.runRange = '392278-393087'
config.Data.unitsPerJob = 2
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'Run2025C_muon0_before_alignment_392278-393087'
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
