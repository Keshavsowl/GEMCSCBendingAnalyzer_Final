from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crabLogs'
config.General.requestName = 'Run2025C_muon0_v02'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 8000
config.JobType.numCores = 4
config.JobType.inputFiles = ['./Run2025C_muon0_ZMu_150X_dataRun3_Prompt_v1_backprop_v3.db']
config.JobType.psetName = 'run_GE21ana.py'
config.section_('Data')
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.runRange = '392278-393087'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 2
config.Data.publication = False
config.Data.outputDatasetTag = 'Run2025C_muon0_iteration1_after_alignment_392278-393087'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
