from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crabLogs'
config.General.requestName = '2025_mc'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.userInputFiles = ['/store/user/kkeshav/SingleMuPt30to50/Phase2_RECO_v1/251222_014014/0000/step3_RECO_1.root']
config.Data.outLFNDirBase = '/store/user/kkeshav/tamu_mual/2025/mc'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = '2025_mc'
config.section_('Site')
config.Site.whitelist = ['T2_CH_CERN']
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
