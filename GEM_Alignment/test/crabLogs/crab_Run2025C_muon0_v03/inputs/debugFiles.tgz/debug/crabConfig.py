from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Run2025C_muon0_v03'
config.General.transferLogs = True
config.General.workArea = 'crabLogs'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxMemoryMB = 8000
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.numCores = 4
config.section_('Data')
config.Data.publication = False
config.Data.inputDataset = '/Muon1/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.outputDatasetTag = 'Run2025C_muon1_before_alignment'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 2
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
