from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crabLogs'
config.General.transferLogs = True
config.General.requestName = 'Run2025C_muon0_v0'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.psetName = 'run_GE21ana.py'
config.section_('Data')
config.Data.publication = False
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outLFNDirBase = '/store/user/toakhter/tamu_mual/2025/2025C'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'Run2025C_muon0_v0'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
