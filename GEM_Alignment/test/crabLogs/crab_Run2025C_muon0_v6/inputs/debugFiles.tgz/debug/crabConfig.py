from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Run2025C_muon0_v6'
config.General.transferLogs = True
config.General.workArea = 'crabLogs'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.psetName = 'run_GE21ana.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.inputDataset = '/Muon0/Run2025C-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outputDatasetTag = 'Run2025C_muon0_before_alignment'
config.Data.unitsPerJob = 2
config.Data.outLFNDirBase = '/store/group/alca_muonalign/kkeshav/'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
