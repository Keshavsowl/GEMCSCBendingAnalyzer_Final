from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crabLogs'
config.General.requestName = '2025mc'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.maxMemoryMB = 2500
config.JobType.psetName = 'run_GE21ana.py'
config.JobType.numCores = 1
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = '2025mc'
config.Data.outLFNDirBase = '/store/user/kkeshav/tamu_mual/2025/mc'
config.Data.splitting = 'FileBased'
config.Data.userInputFiles = ['root://eoscms.cern.ch//eos/cms/store/user/kkeshav/SingleMuPt30to50/Phase2_RECO_v1/251222_014014/0000/step3_RECO_1.root']
config.Data.unitsPerJob = 1
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.Site.whitelist = ['T2_CH_CERN']
config.section_('User')
config.section_('Debug')
