import FWCore.ParameterSet.Config as cms

def MuonAnalyser(*args, **kwargs):
  mod = cms.EDAnalyzer('MuonAnalyser',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
