import FWCore.ParameterSet.Config as cms

def ME11ana(*args, **kwargs):
  mod = cms.EDAnalyzer('ME11ana',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
