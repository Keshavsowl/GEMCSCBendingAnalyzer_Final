import FWCore.ParameterSet.Config as cms

def GEMAlDBWriter(*args, **kwargs):
  mod = cms.EDAnalyzer('GEMAlDBWriter',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
