import FWCore.ParameterSet.Config as cms

def analyzer(*args, **kwargs):
  mod = cms.EDAnalyzer('analyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
