import FWCore.ParameterSet.Config as cms

def ge21analyzer(*args, **kwargs):
  mod = cms.EDAnalyzer('ge21analyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
